# Lab2-LinkedLists
Follow the Instructions found in Lab2-Linked_Lists.odt and use the code in the code/ folder to complete this lab.
